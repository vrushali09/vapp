package com.example.vrushaligaikwad.videoapplication;

/**
 * Created by vrushali gaikwad on 29-10-2016.
 */
public class UserContract {
    public static abstract class NewUserInfo
    {
        public static final String USER_NAME = "user_name";
        public static final String TABLE_NAME ="user_info";
    }
}
